'use strict';

ApplicationConfiguration.registerModule('articles');
