'use strict';

angular.module('articles').run(['Menus',
  function (Menus) {

  }
]);
